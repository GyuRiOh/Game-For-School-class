﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class checkBedPuzzle : MonoBehaviour {
    public static bool[] onOff = { false, false, false, false };
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
